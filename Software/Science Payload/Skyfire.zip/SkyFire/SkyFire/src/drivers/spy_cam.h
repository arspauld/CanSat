/*
 * spy_cam.h
 *
 * Created: 4/14/2019 12:44:19 AM
 *  Author: Pat Smith
 */ 

#include <asf.h>

#ifndef SPY_CAM_H_
#define SPY_CAM_H_


void cam_init(void);
void cam_switch(void);


#endif /* SPY_CAM_H_ */