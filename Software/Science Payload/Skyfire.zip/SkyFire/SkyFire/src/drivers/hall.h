/*
 * hall.h
 *
 * Created: 5/13/2019 2:44:41 PM
 *  Author: Pat Smith
 */ 

#include <asf.h>

#ifndef HALL_H_
#define HALL_H_


void hall_sensor_init(void);


#endif /* HALL_H_ */