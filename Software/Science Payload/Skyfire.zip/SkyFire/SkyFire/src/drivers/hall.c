/*
 * hall.c
 *
 * Created: 5/13/2019 2:44:29 PM
 *  Author: Pat Smith
 */ 

#include <asf.h>
#include "hall.h"

void hall_sensor_init(void){
	
}