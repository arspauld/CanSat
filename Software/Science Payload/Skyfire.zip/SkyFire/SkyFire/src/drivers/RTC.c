/*
 * RTC.c
 *
 * Created: 5/6/2019 10:24:32 AM
 *  Author: Pat Smith
 */ 

#include <asf.h>
#include "RTC.h"